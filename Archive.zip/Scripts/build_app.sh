#!/bin/bash
# Builds Electron in release mode and assembles it into a double-clickable
# Electron.app bundle in the project root. Run from the project root:
#   ./Scripts/build_app.sh
set -euo pipefail

APP_NAME="Electron"
BUILD_DIR=".build/release"
APP_BUNDLE="${APP_NAME}.app"

echo "→ Building ${APP_NAME} (release)…"
swift build -c release

echo "→ Assembling ${APP_BUNDLE}…"
rm -rf "${APP_BUNDLE}"
mkdir -p "${APP_BUNDLE}/Contents/MacOS"
mkdir -p "${APP_BUNDLE}/Contents/Resources"

cp "${BUILD_DIR}/${APP_NAME}" "${APP_BUNDLE}/Contents/MacOS/${APP_NAME}"
cp "Sources/${APP_NAME}/Resources/Info.plist" "${APP_BUNDLE}/Contents/Info.plist"

# Bundle any additional processed resources SPM produced alongside the binary.
if [ -d "${BUILD_DIR}/${APP_NAME}_${APP_NAME}.bundle" ]; then
    cp -R "${BUILD_DIR}/${APP_NAME}_${APP_NAME}.bundle" "${APP_BUNDLE}/Contents/Resources/"
fi

echo "→ Adding app icon…"
ASSET_CATALOG="Sources/${APP_NAME}/Resources/Assets.xcassets"
if [ -d "${ASSET_CATALOG}" ] && command -v actool >/dev/null 2>&1; then
    # Compiles Assets.xcassets/AppIcon.appiconset into Assets.car directly
    # inside the bundle, matching the CFBundleIconName set in Info.plist.
    actool --output-format human-readable-text --notices --warnings \
        --output-partial-info-plist /tmp/electron_generated_info.plist \
        --app-icon AppIcon --compile "${APP_BUNDLE}/Contents/Resources" \
        --platform macosx --minimum-deployment-target 13.0 \
        "${ASSET_CATALOG}" >/dev/null
elif [ -f "Sources/${APP_NAME}/Resources/AppIcon.icns" ]; then
    # Fallback for machines without actool on PATH: ship the pre-built .icns.
    cp "Sources/${APP_NAME}/Resources/AppIcon.icns" "${APP_BUNDLE}/Contents/Resources/AppIcon.icns"
fi

echo "→ Ad-hoc code signing…"
codesign --force --deep --sign - "${APP_BUNDLE}"

echo "✓ Built ${APP_BUNDLE}. Move it to /Applications or run:"
echo "  open ${APP_BUNDLE}"
