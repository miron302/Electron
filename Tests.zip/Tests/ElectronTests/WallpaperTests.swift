import XCTest
@testable import Electron

final class WallpaperTests: XCTestCase {
    func makeSample(mediaType: WallpaperMediaType = .video) -> Wallpaper {
        Wallpaper(
            id: "test-1",
            title: "Sample",
            providerID: "test",
            providerDisplayName: "Test",
            sourcePageURL: URL(string: "https://example.com")!,
            author: "Jane Doe",
            authorPageURL: URL(string: "https://example.com/jane")!,
            licenseSummary: "Free to use",
            previewImageURL: URL(string: "https://example.com/preview.jpg")!,
            mediaURL: URL(string: "https://example.com/video.mp4")!,
            mediaType: mediaType,
            width: 1920,
            height: 1080,
            durationSeconds: 12,
            tags: ["nature"],
            category: .nature
        )
    }

    func testLocalFileNameMatchesMediaType() {
        XCTAssertEqual(makeSample(mediaType: .video).localFileName, "test-1.mp4")
        XCTAssertEqual(makeSample(mediaType: .animatedGIF).localFileName, "test-1.gif")
    }

    func testAspectRatioComputation() {
        XCTAssertEqual(makeSample().aspectRatio, 1920.0 / 1080.0, accuracy: 0.0001)
    }

    func testWallpaperRoundTripsThroughJSON() throws {
        let original = makeSample()
        let data = try JSONEncoder().encode(original)
        let decoded = try JSONDecoder().decode(Wallpaper.self, from: data)
        XCTAssertEqual(original, decoded)
    }

    func testCategorySearchTermSkipsAll() {
        XCTAssertNil(WallpaperCategory.all.searchTerm)
        XCTAssertEqual(WallpaperCategory.ocean.searchTerm, "ocean")
    }
}
